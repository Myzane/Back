<?php
return array(
    'current_version'=>'2.3.0',
    'update_version'=>"2.4.0"
);
